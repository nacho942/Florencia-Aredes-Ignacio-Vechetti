/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package periodictable;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class Search {
    public void buscarElemento(String elemento, 
            JLabel nombre,
            JLabel simbolo,
            JLabel num_m,
            JLabel num_a,
            JLabel valencias,
            JLabel config_e,
            JLabel electronegatividad) throws IOException{
        try {
            
            URL url = new URL("https://neelpatel05.pythonanywhere.com/element/atomicname?atomicname=" + elemento.toLowerCase());
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            int responseCode = con.getResponseCode();
            if (responseCode != 200) {
                throw new RuntimeException("Error! " + responseCode);
            } else {
                String informacionString = "";
                Scanner scanner = new Scanner(url.openStream());

               while (scanner.hasNext()){
                informacionString=scanner.nextLine();
            }
            scanner.close();
            String[] lista = informacionString.split(",");
            JSONArray jsonArray = new JSONArray(Arrays.toString(lista));
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            scanner.close();
            
            nombre.setText(jsonObject.getString("name"));
            simbolo.setText(jsonObject.getString("symbol"));
            electronegatividad.setText(jsonObject.getBigDecimal("electronegativity").toString());
            num_a.setText(jsonObject.getBigInteger("atomicNumber").toString());
            num_m.setText(jsonObject.getString("atomicMass"));
            config_e.setText(jsonObject.getString("electronicConfiguration"));
            valencias.setText(jsonObject.getString("oxidationStates"));
            }
        } catch (JSONException e) {
           JOptionPane.showMessageDialog(null, "Elemento no encontrado");
        }
        
    }
    
    public void setImage(String elemento, JLabel label){
        try{
            label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/periodictable/imagenes/"+
                    elemento.toLowerCase() +" (Personalizado).jpg")));
        }catch(NullPointerException ex){
            label.setText("imagen no encontrada");
        
        }
    }
    
}